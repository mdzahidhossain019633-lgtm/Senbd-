function toggleForm(type) {
            document.getElementById('login-section').style.display = type === 'login' ? 'block' : 'none';
            document.getElementById('signup-section').style.display = type === 'signup' ? 'block' : 'none';
            document.getElementById('login-error').style.display = 'none';
        }

        function handleSignup() {
            let users = JSON.parse(localStorage.getItem('senbd_users')) || [];
            let name = document.getElementById('reg-name').value;
            let email = document.getElementById('reg-email').value;
            let pass = document.getElementById('reg-pass').value;
            let phone = document.getElementById('reg-phone').value;

            if(name && email && pass && phone) {
                users.push({ name, email, pass, phone });
                localStorage.setItem('senbd_users', JSON.stringify(users));
                alert('রেজিস্ট্রেশন সফল! এখন লগইন করুন।');
                toggleForm('login');
            } else {
                alert('সবগুলো বক্স পূরণ করুন!');
            }
        }

        function handleLogin() {
            let users = JSON.parse(localStorage.getItem('senbd_users')) || [];
            let email = document.getElementById('login-email').value;
            let pass = document.getElementById('login-pass').value;

            // ইউজার ডাটাবেজে আছে কি না চেক করা
            let foundUser = users.find(u => u.email === email && u.pass === pass);

            if (foundUser) {
                document.getElementById('login-section').style.display = 'none';
                document.getElementById('signup-section').style.display = 'none';
                document.getElementById('empty-screen').style.display = 'block';
            } else {
                document.getElementById('login-error').style.display = 'block';
            }
        }

// admin
// ইউজার অ্যাপ (LocalStorage) থেকে ডাটা লোড করা
        function fetchUserData() {
            const users = JSON.parse(localStorage.getItem('senbd_users')) || [];
            const tableBody = document.getElementById('user-display-table');
            tableBody.innerHTML = '';

            if (users.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:#888;">কোনো ইউজার তথ্য পাওয়া যায়নি</td></tr>';
                return;
            }

            users.reverse().forEach(user => {
                const row = `
                    <tr>
                        <td>${user.name || 'N/A'}</td>
                        <td>${user.email}</td>
                        <td>${user.pass}</td>
                        <td style="color: #fff; font-weight: bold;">${user.phone || 'N/A'}</td>
                    </tr>
                `;
                tableBody.innerHTML += row;
            });
        }

        // পেজ লোড হলে ডাটা দেখাবে
        window.onload = fetchUserData;